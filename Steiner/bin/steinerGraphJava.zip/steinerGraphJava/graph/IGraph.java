package steinerGraphJava.graph;

import java.io.File;
import java.util.Hashtable;
import java.util.LinkedList;

public interface IGraph {
	public Node[] getNodes();
	
	public void removeNode(Node n);
	
	public LinkedList<Arc> getShape();
	
	public int getMaxTerminalNodeId();
	
	public void loadFile(File f);
	
	public Hashtable<Node, String> getUserAssociatedNodeNames();

	public String convertNodeToName(Node node);

	public Node convertNameToNode(String node);
}
