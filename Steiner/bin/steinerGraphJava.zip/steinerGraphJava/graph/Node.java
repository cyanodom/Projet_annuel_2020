package steinerGraphJava.graph;

public class Node {
	private int name;
	
	public Node(int name) {
		this.name = name;
	}
	
	public int getName() {
		return name;
	}
}
