package steinerGraphJava.graph.graphFile;

public class GraphFileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8482200344823171250L;
}
