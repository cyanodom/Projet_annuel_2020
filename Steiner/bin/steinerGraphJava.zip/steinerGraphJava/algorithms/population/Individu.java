package steinerGraphJava.algorithms.population;

public class Individu {
	
	// ATTRIBUTS
	
	private int[] individu;
	
	
	// CONSTRUCTEUR
	
	public Individu(int[] individu) {
		this.individu = individu;
	}
	
	
	// REQUETES
	
	public int[] getIndividu() {
		return individu;
	}
}
