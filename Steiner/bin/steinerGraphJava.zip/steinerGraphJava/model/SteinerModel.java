package steinerGraphJava.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Observable;
import java.util.Observer;

import steinerGraphJava.algorithms.kruskal.Kruskal;
import steinerGraphJava.graph.IGraph;
import steinerGraphJava.graph.graphFile.IGraphFile;

public class SteinerModel extends Observable implements ISteinerModel {

	private File file;
	
	public SteinerModel() {
		
	}
	
	// OUTILS
	
	private void runAlgo() {
		file = new File("misc/text.txt");

		// Partie Reader
		this.struct = new StructFile();

		try {
			reader = new Reader(struct, file);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		try {
			reader.translate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			reader.read();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// PARTIE HashTable

		/*
		 * Faire la HashTable
		 */

		// PARTIE génétique

		switch(struct.getNomSommetsT().length) {
		case 1 :
			System.out.println("Arbre Final : " + struct.getNomSommetsT()[0]);
			System.out.println("Poids de 0");
			break;
		case 2 :
			// DIJKSTRA
			break;
		default :
			if (struct.getNomSommetsT().length == struct.getNbSommets()) {
				// SI S = T
				Kruskal kruskal = new Kruskal(struct, reader.getLength());
				int[][] tab = kruskal.kruskal();
			} else {
				gene = new Genetique(struct);
				gene.AlgoGene();
			}
			break;
		}
	}

	public IGraph getGraph() {
		// TODO Auto-generated method stub
		return null;
	}
}
